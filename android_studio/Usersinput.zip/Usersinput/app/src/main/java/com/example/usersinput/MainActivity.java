package com.example.usersinput;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText nameText = (EditText) findViewById(R.id.editText);

        nameText.setFilters(new InputFilter[] {
                new InputFilter.LengthFilter(10),
                new InputFilter.AllCaps()

            });
        EditText nameText2 = (EditText) findViewById(R.id.editText2);

        nameText2.setFilters(new InputFilter[] {
                new InputFilter.LengthFilter(10),
                new InputFilter.AllCaps()

        });
        EditText nameText3 = (EditText) findViewById(R.id.editText3);

        nameText3.setFilters(new InputFilter[] {
                new InputFilter.LengthFilter(10),
                new InputFilter.AllCaps()

        });

        final EditText passwordField = (EditText) findViewById(R.id.editText);

        Button submitButton = (Button) findViewById(R.id.button5);
        submitButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String text = passwordField.getText().toString();

                boolean valid = true;
                boolean hasNumbers = false;
                boolean hasLetters = false;

                for (int i=0; i<text.length(); i++) {
                    if (Character.isDigit(text.charAt(i))){
                        hasNumbers = true;
                    }
                    else if (Character.isLetter(text.charAt(i))) {
                        hasLetters = true;
                    } else {
                        valid = true;
                        break;
                    }
                }

                if (valid && hasLetters && hasNumbers) {
                    Toast.makeText(getBaseContext(), "Password " + text + " is valid.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getBaseContext(), "Password " + text + " is not valid", Toast.LENGTH_SHORT).show();
                }
            }

        });



    }

}
